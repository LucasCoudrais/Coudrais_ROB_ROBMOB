turtlebot_simulator
===================

Launchers for Gazebo simulation of the TurtleBot

- see [how to start simulation](./simulation/gazebo/gazebo_sim_nav/Readme.md)
- see [Ros Navigation Stack Pratical Work](./simulation/gazebo/gazebo_sim_nav/Tp.md)
- see [Ros Navigation Stack Local Planner Pratical Work](./turtlebot_gazebo/Tp2.md)
